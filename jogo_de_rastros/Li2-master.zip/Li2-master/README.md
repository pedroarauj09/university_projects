# Li2

CURSO:MIEI

Alunos esses que pertence ao PL1-Grupo 2, sendo eles:

Pedro Aquino Martins de Araujo- A90614

Pedro Henrique do Vale Saldanha- A90618

Vitor Lelis Noronha Leite- A90707
