var searchData=
[
  ['possiveis_5fjog',['possiveis_jog',['../structESTADO.html#ab9b11998a54bde459f72cbbc32e79b0b',1,'ESTADO']]],
  ['prox',['prox',['../structlista.html#a3b0e375147c1163d74544fd206a1f1de',1,'lista']]]
];
