var searchData=
[
  ['valor',['valor',['../structlista.html#a1851230b0237deef0519ee33de9f2dd0',1,'lista']]]
];
