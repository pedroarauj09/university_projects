var indexSectionsWithContent =
{
  0: "cejlnpqrtuv",
  1: "cejl",
  2: "cjlnpqtuv",
  3: "lr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Variables",
  3: "Pages"
};

