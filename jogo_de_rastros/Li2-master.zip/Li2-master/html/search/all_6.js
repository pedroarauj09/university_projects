var searchData=
[
  ['qntjogs',['qntjogs',['../structESTADO.html#ae0aaae1dc17799598305cd40a3ca2ba8',1,'ESTADO']]]
];
