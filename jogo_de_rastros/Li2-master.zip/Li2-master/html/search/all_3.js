var searchData=
[
  ['letra',['letra',['../structCOORDENADA.html#acb526f8ae91ba6a2742ef1a9473fa2b4',1,'COORDENADA']]],
  ['letrinha',['letrinha',['../structCOORDENADA.html#ac00ff2e615b371a3d87fbb05449cde99',1,'COORDENADA']]],
  ['linha',['linha',['../structCOORDENADA.html#aefe14bcc5a066ac3b21500cc3d28c06f',1,'COORDENADA']]],
  ['lista',['lista',['../structlista.html',1,'']]],
  ['li2',['Li2',['../md_README.html',1,'']]]
];
