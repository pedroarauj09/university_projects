var searchData=
[
  ['coordenada',['COORDENADA',['../structCOORDENADA.html',1,'']]],
  ['count_5fjog',['count_jog',['../structESTADO.html#a5632721fdfcc6c98f084c91aef5b6e25',1,'ESTADO']]],
  ['count_5fmov',['count_mov',['../structESTADO.html#a36e8d21ac156e82ce914ccdafc6796ea',1,'ESTADO']]],
  ['count_5fmovs',['count_movs',['../structESTADO.html#a49b04d6940f820509146c9162ac10542',1,'ESTADO']]]
];
