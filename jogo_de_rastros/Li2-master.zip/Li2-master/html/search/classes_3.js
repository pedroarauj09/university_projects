var searchData=
[
  ['lista',['lista',['../structlista.html',1,'']]]
];
