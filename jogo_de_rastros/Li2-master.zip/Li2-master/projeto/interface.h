#ifndef LI2_INTERFACE_H
#define LI2_INTERFACE_H
#include "lista.h"
void mostrar_tabuleiro(ESTADO *e);
int interpretador(ESTADO *e);
#endif //LI2_INTERFACE_H