
MIEI-UC 1º ano-2º SEMESTRE 
Numeração do grupo:2 
PL1
Grupo: Pedro Aquino A90614
       Pedro Saldanha A90618
       Vitor Lelis A90707


Relatorio (Guião 5)


Objetivo:Neste guião tivemos como tarefa produzir modulos, além de desenvolver código para cada modulo sendo eles (CamadaDeDados,logica, interface).


Desafios: Nas primeiras impressões o código de exemplo parecia ser demasiado complexo pelo facto de utilizar algumas funções não apresentadas ou estudadas em sala de aula,com isso,foi 
preciso sentar os três a tentar analisar o código que vos foi dado, além disso, tivemos uma discursão o que seria melhor para o desenvolvimento do trabalho,fazer o nosso próprio código ou 
utilizar os ja estava pre estabelecido.Sendo assim, depois de 3 dias de analise de código para percebemos o que cada função faz, começamos a reparar o como as partes se encaixavam de 
forma simples e clara e então inicializamos o nosso desenvolvimento. Diante disto, ficamos um pouco perdidos em relação o que tínhamos que complementar e como poderíamos construir um código para que ficasse
tão compacto e simples como o já estabelecido.Embora,apesar  nos apresentar um código que é simples nos faltava conhecimento mas conseguimos aprender um pouco mais das funções e com os nossos erros em testes.


 
